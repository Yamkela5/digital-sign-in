// Global variables for charts and data
const elements = {
  // Header elements
  currentTime: document.getElementById('current-time'),
  headerUsername: document.getElementById('header-username'),
  headerAvatar: document.getElementById('header-avatar'),
  headerProfileImage: document.getElementById('header-profile-image'),
  
  // Dashboard elements
  presentCount: document.getElementById('presentCount'),
  absentCount: document.getElementById('absentCount'),
  lateCount: document.getElementById('lateCount'),
  totalCount: document.getElementById('totalCount'),
  
  // Attendance table
  attendanceTableBody: document.getElementById('attendanceTableBody'),
  
  // Filters
  cohortFilter: document.getElementById('cohortFilter'),
  dateFilter: document.getElementById('dateFilter'),
  searchInput: document.getElementById('searchInput'),
  applyFiltersBtn: document.getElementById('applyFiltersBtn'),
  exportCSVBtn: document.getElementById('exportCSVBtn')
};

let chartData = {
    daily: {
        labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'],
        present: [40, 45, 42, 40, 35],
        absent: [5, 7, 8, 10, 15],
        late: [10, 5, 10, 10, 10]
    },
    weekly: {
        labels: ['Week 1', 'Week 2', 'Week 3', 'Week 4'],
        present: [200, 210, 190, 205],
        absent: [30, 25, 40, 35],
        late: [20, 15, 20, 10]
    },
    monthly: {
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
        present: [800, 820, 810, 790, 805, 815],
        absent: [120, 110, 130, 140, 125, 115],
        late: [80, 70, 90, 85, 75, 70]
    }
};

// Attendance data
let attendanceData = {
    candidates: [],
    attendance: [],
    filteredAttendance: [],
    allAttendance: [] // Store all attendance records for client-side filtering
};

let attendanceChart = null;
let currentChartPeriod = 'daily';

// Global modal functions
window.showAddCandidateModal = function() {
    console.log('showAddCandidateModal called globally');
    window.showModal('addCandidateModal');
};

window.showQRCode = function() {
    console.log('showQRCode called globally');
    window.showModal('qrModal');
};

window.refreshData = async function() {
    console.log('refreshData called globally');
    await fetchAttendanceData();
    window.showToast('Data refreshed successfully!', 'success');
};

// Generic modal functions
window.showModal = function(modalId) {
    console.log('Showing modal:', modalId);
    const modal = document.getElementById(modalId);
    if (!modal) {
        console.error(`Modal with ID ${modalId} not found`);
        return;
    }
    console.log('Before removing hidden class:', modal.className);
    modal.classList.remove('hidden');
    console.log('After removing hidden class:', modal.className);
    document.body.classList.add('modal-open');
};

window.hideModal = function(modalId) {
    console.log('Hiding modal:', modalId);
    const modal = document.getElementById(modalId);
    if (!modal) {
        console.error(`Modal with ID ${modalId} not found`);
        return;
    }
    modal.classList.add('hidden');
    document.body.classList.remove('modal-open');
};

// Toast notification function
window.showToast = function(message, type = 'info') {
    console.log('Showing toast:', message, type);
    const toastContainer = document.querySelector('.toast-container') || createToastContainer();
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.innerHTML = `
        <div class="toast-content">
            <span>${message}</span>
        </div>
    `;
    toastContainer.appendChild(toast);
    
    // Auto-remove toast after 3 seconds
    setTimeout(() => {
        toast.classList.add('toast-hide');
        setTimeout(() => toast.remove(), 300);
    }, 3000);
};

// Helper function to create toast container if it doesn't exist
function createToastContainer() {
    const container = document.createElement('div');
    container.className = 'toast-container';
    document.body.appendChild(container);
    return container;
}

// Fetch all candidates from Supabase
async function fetchCandidates() {
    try {
        const { data, error } = await window.supabase
            .from('candidates')
            .select('*');
        
        if (error) {
            console.error('Error fetching candidates:', error);
            window.showToast('Error fetching candidates', 'error');
            return [];
        }
        
        console.log('Fetched candidates:', data);
        return data || [];
    } catch (err) {
        console.error('Exception fetching candidates:', err);
        window.showToast('Unexpected error fetching candidates', 'error');
        return [];
    }
}

// Fetch attendance data from Supabase - CLIENT-SIDE FILTERING APPROACH
async function fetchAttendance(date = null) {
    try {
        // Fetch all attendance records without filtering by date
        const { data, error } = await window.supabase
            .from('attendance')
            .select('*')
            .order('date', { ascending: false });
        
        if (error) {
            console.error('Error fetching attendance:', error);
            window.showToast('Error fetching attendance data', 'error');
            return [];
        }
        
        // Store all attendance records for future filtering
        attendanceData.allAttendance = data || [];
        
        // Filter on the client side if date is provided
        let filteredData = attendanceData.allAttendance;
        if (date && filteredData.length > 0) {
            filteredData = filteredData.filter(record => record.date === date);
        }
        
        console.log('Fetched attendance:', filteredData);
        return filteredData;
    } catch (err) {
        console.error('Exception fetching attendance:', err);
        window.showToast('Unexpected error fetching attendance data', 'error');
        return [];
    }
}

// Fetch all attendance data
async function fetchAttendanceData() {
    // Get today's date in YYYY-MM-DD format
    const today = new Date().toISOString().split('T')[0];
    
    // Set default date in date filter if not already set
    if (elements.dateFilter && !elements.dateFilter.value) {
        elements.dateFilter.value = today;
    }
    
    // Fetch candidates and attendance data
    const [candidates, attendance] = await Promise.all([
        fetchCandidates(),
        fetchAttendance(today) // Default to today's attendance
    ]);
    
    // Store data
    attendanceData.candidates = candidates;
    attendanceData.attendance = attendance;
    
    // Update UI
    updateAttendanceCounts();
    updateAttendanceTable();
    
    return { candidates, attendance };
}

// Update attendance counts in dashboard
function updateAttendanceCounts() {
    if (!elements.presentCount || !elements.absentCount || !elements.lateCount || !elements.totalCount) {
        console.warn('Attendance count elements not found');
        return;
    }
    
    const totalCandidates = attendanceData.candidates.length;
    const presentCount = attendanceData.attendance.filter(a => a.status === 'Present').length;
    const lateCount = attendanceData.attendance.filter(a => a.status === 'Late').length;
    const absentCount = totalCandidates - (presentCount + lateCount);
    
    elements.presentCount.textContent = presentCount;
    elements.lateCount.textContent = lateCount;
    elements.absentCount.textContent = absentCount;
    elements.totalCount.textContent = totalCandidates;
}

// Update attendance table with filtered data
function updateAttendanceTable() {
    if (!elements.attendanceTableBody) {
        console.warn('Attendance table body not found');
        return;
    }
    
    // Clear table
    elements.attendanceTableBody.innerHTML = '';
    
    // Get filtered data
    const filteredData = getFilteredAttendance();
    attendanceData.filteredAttendance = filteredData;
    
    // Add rows to table
    filteredData.forEach(record => {
        const row = document.createElement('tr');
        
        row.innerHTML = `
            <td class="px-4 py-3 text-sm">${record.full_name}</td>
            <td class="px-4 py-3 text-sm">${record.cohort}</td>
            <td class="px-4 py-3 text-sm">${record.date}</td>
            <td class="px-4 py-3 text-sm">${record.time}</td>
            <td class="px-4 py-3 text-sm">
                <span class="status-badge status-${record.status.toLowerCase()}">${record.status}</span>
            </td>
            <td class="px-4 py-3 text-sm">${record.reason || '-'}</td>
            <td class="px-4 py-3 text-sm">
                <button class="action-btn" data-id="${record.id}" data-action="view">
                    <i data-lucide="eye" class="w-4 h-4"></i>
                </button>
            </td>
        `;
        
        elements.attendanceTableBody.appendChild(row);
    });
    
    // Initialize Lucide icons for new rows
    if (window.lucide) {
        window.lucide.createIcons();
    }
    
    // Add event listeners to action buttons
    document.querySelectorAll('.action-btn[data-action="view"]').forEach(btn => {
        btn.addEventListener('click', () => {
            const id = btn.getAttribute('data-id');
            viewAttendanceDetails(id);
        });
    });
}

// Get filtered attendance data based on current filters - CLIENT-SIDE FILTERING
function getFilteredAttendance() {
    // Start with all attendance records
    let filtered = [...attendanceData.allAttendance];
    
    // Apply date filter
    if (elements.dateFilter && elements.dateFilter.value) {
        filtered = filtered.filter(record => record.date === elements.dateFilter.value);
    }
    
    // Apply cohort filter
    if (elements.cohortFilter && elements.cohortFilter.value !== 'all') {
        filtered = filtered.filter(record => record.cohort === elements.cohortFilter.value);
    }
    
    // Apply search filter
    if (elements.searchInput && elements.searchInput.value.trim()) {
        const searchTerm = elements.searchInput.value.trim().toLowerCase();
        filtered = filtered.filter(record => 
            record.full_name.toLowerCase().includes(searchTerm) ||
            (record.reason && record.reason.toLowerCase().includes(searchTerm))
        );
    }
    
    return filtered;
}

// View attendance details
function viewAttendanceDetails(id) {
    const record = attendanceData.filteredAttendance.find(r => r.id === id);
    if (!record) {
        window.showToast('Attendance record not found', 'error');
        return;
    }
    
    // In a real app, you would show a modal with details
    console.log('Viewing attendance details:', record);
    window.showToast(`Viewing details for ${record.full_name}`, 'info');
}

// Export attendance data to CSV
function exportAttendanceToCSV() {
    const filteredData = attendanceData.filteredAttendance;
    if (!filteredData || filteredData.length === 0) {
        window.showToast('No data to export', 'warning');
        return;
    }
    
    // Create CSV content
    let csvContent = "data:text/csv;charset=utf-8,";
    csvContent += "Name,Cohort,Date,Time,Status,Reason\n";
    
    filteredData.forEach(record => {
        csvContent += `"${record.full_name}","${record.cohort}","${record.date}","${record.time}","${record.status}","${record.reason || ''}"\n`;
    });
    
    // Create download link
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", "attendance_export.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    window.showToast('Attendance data exported successfully', 'success');
}

// Handle adding a new candidate with automatic authentication user creation
async function handleAddCandidate(e) {
    e.preventDefault();
    
    // Get form values
    const nameInput = document.getElementById('candidateName');
    const cohortInput = document.getElementById('candidateCohort');
    const emailInput = document.getElementById('candidateEmail');
    const mobileInput = document.getElementById('candidateMobile');
    const passwordInput = document.getElementById('candidatePassword');
    
    if (!nameInput || !cohortInput || !emailInput || !mobileInput || !passwordInput) {
        console.error("Candidate form elements not found");
        window.showToast('Form elements not found. Please try again.', 'error');
        return;
    }
    
    const name = nameInput.value.trim();
    const cohort = cohortInput.value.trim();
    const email = emailInput.value.trim();
    const mobile = mobileInput.value.trim();
    const password = passwordInput.value.trim();
    
    // Validate inputs
    if (!name || !cohort || !email || !mobile || !password) {
        window.showToast('Please fill in all fields.', 'error');
        return;
    }

    try {
        // Check if supabase is available
        if (!window.supabase) {
            console.error("Supabase client not available");
            window.showToast('Database connection not available. Please try again later.', 'error');
            return;
        }
        
        // 1. First create the authentication user
        console.log('Creating authentication user for:', email);
        const { data: authData, error: authError } = await window.supabase.auth.signUp({
            email: email,
            password: password,
            options: {
                data: {
                    full_name: name,
                    cohort: cohort
                }
            }
        });

        if (authError) {
            console.error('Auth error:', authError);
            window.showToast('Error creating user: ' + authError.message, 'error');
            return;
        }
        
        console.log('Authentication user created successfully:', authData.user.id);

        // 2. Then add the user to your candidates table
        const { data, error } = await window.supabase
            .from('candidates')
            .insert([{ 
                full_name: name, 
                cohort: cohort, 
                email: email, 
                mobile: mobile,
                auth_id: authData.user.id  // Link to the auth user
            }]);

        if (error) {
            console.error('Insert error:', error);
            window.showToast('Error adding candidate: ' + error.message, 'error');
            return;
        }

        // Success handling
        console.log('Candidate added successfully to database');
        window.showToast(`${name} added successfully`, 'success');
        document.getElementById('addCandidateForm').reset();
        window.hideModal('addCandidateModal');
        
        // Refresh data to include new candidate
        fetchAttendanceData();
        
    } catch (err) {
        console.error('Unexpected error:', err);
        window.showToast('Unexpected error adding candidate. Please try again.', 'error');
    }
}

// Handle page navigation
function handlePageNavigation() {
    const navButtons = document.querySelectorAll('.sidebar-menu-item');
    const pages = document.querySelectorAll('.page-content');
    
    navButtons.forEach(button => {
        button.addEventListener('click', function() {
            const targetPage = this.getAttribute('data-page');
            if (!targetPage) return;
            
            // Update active state
            navButtons.forEach(btn => btn.classList.remove('bg-[#2a3a52]', 'font-medium'));
            this.classList.add('bg-[#2a3a52]', 'font-medium');
            
            // Show target page, hide others
            pages.forEach(page => {
                if (page.id === `${targetPage}Page`) {
                    page.classList.remove('hidden');
                } else {
                    page.classList.add('hidden');
                }
            });
            
            // Special handling for attendance page
            if (targetPage === 'attendance') {
                fetchAttendanceData();
            }
        });
    });
}

// Initialize the application
document.addEventListener('DOMContentLoaded', async function() {
    console.log('DOM fully loaded - initializing application');
    
    // Initialize Lucide icons
    if (window.lucide) {
        console.log('Lucide icons initialized');
        window.lucide.createIcons();
    } else {
        console.warn('Lucide library not found');
    }
    
    // Load admin profile
    loadAdminProfile();
    
    // Check if all required global functions are available
    console.log('Checking global functions availability:');
    console.log('showAddCandidateModal:', typeof window.showAddCandidateModal);
    console.log('showQRCode:', typeof window.showQRCode);
    console.log('refreshData:', typeof window.refreshData);
    console.log('showModal:', typeof window.showModal);
    console.log('hideModal:', typeof window.hideModal);
    console.log('showToast:', typeof window.showToast);
    
    // Initialize event listeners
    console.log('Initializing event listeners');
    initEventListeners();
    
    // Initialize charts
    console.log('Initializing charts');
    initCharts();
    
    // Set current date in dashboard
    const dashboardDate = document.getElementById('dashboardDate');
    if (dashboardDate) {
        dashboardDate.textContent = new Date().toLocaleDateString('en-US', {
            weekday: 'long',
            year: 'numeric',
            month: 'long',
            day: 'numeric'
        });
    }
    
    // Set today's date as default in date filter
    if (elements.dateFilter) {
        elements.dateFilter.value = new Date().toISOString().split('T')[0];
    }
    
    // Fetch initial data
    await fetchAttendanceData();
    
    // Initialize page navigation
    handlePageNavigation();
});

// Load admin profile from session storage
function loadAdminProfile() {
    try {
        const userProfileStr = sessionStorage.getItem('userProfile');
        if (userProfileStr) {
            const userProfile = JSON.parse(userProfileStr);
            const adminNameElement = document.getElementById('adminName');
            if (adminNameElement && userProfile.full_name) {
                adminNameElement.textContent = userProfile.full_name;
                console.log('Admin profile loaded:', userProfile.full_name);
            }
        }
    } catch (err) {
        console.error('Error loading admin profile:', err);
    }
}

// Initialize all event listeners
function initEventListeners() {
    // Add candidate button
    const addCandidateButton = document.getElementById('addCandidateBtn');
    if (addCandidateButton) {
        addCandidateButton.addEventListener('click', function() {
            console.log('Add candidate button clicked');
            window.showAddCandidateModal();
        });
        console.log('Add candidate button listener attached');
    }
    
    // Show QR code button
    const showQRButton = document.getElementById('showQRBtn');
    if (showQRButton) {
        showQRButton.addEventListener('click', function() {
            console.log('Show QR button clicked');
            window.showQRCode();
        });
        console.log('Show QR button listener attached');
    }
    
    // Refresh data button
    const refreshButton = document.getElementById('refreshDataBtn');
    if (refreshButton) {
        refreshButton.addEventListener('click', function() {
            console.log('Refresh data button clicked');
            window.refreshData();
        });
        console.log('Refresh data button listener attached');
    }
    
    // Chart period tabs
    const chartTabs = document.querySelectorAll('.chart-tab');
    chartTabs.forEach(tab => {
        tab.addEventListener('click', function() {
            const period = this.getAttribute('data-period');
            if (period) {
                updateChart(period);
                
                // Update active tab
                chartTabs.forEach(t => t.classList.remove('active'));
                this.classList.add('active');
            }
        });
    });
    
    // Modal close buttons
    document.querySelectorAll('.modal .close-button').forEach(button => {
        button.addEventListener('click', function() {
            const modal = this.closest('.modal');
            if (modal) {
                window.hideModal(modal.id);
            }
        });
    });
    
    // Add candidate form submission
    const addCandidateForm = document.getElementById('addCandidateForm');
    if (addCandidateForm) {
        addCandidateForm.addEventListener('submit', handleAddCandidate);
    }
    
    // Cancel buttons in modals
    document.querySelectorAll('.modal button.cancel-btn').forEach(button => {
        button.addEventListener('click', function() {
            const modal = this.closest('.modal');
            if (modal) {
                window.hideModal(modal.id);
            }
        });
    });
    
    // Attendance filters
    if (elements.applyFiltersBtn) {
        elements.applyFiltersBtn.addEventListener('click', function() {
            updateAttendanceTable();
        });
    }
    
    // Export CSV button
    if (elements.exportCSVBtn) {
        elements.exportCSVBtn.addEventListener('click', function() {
            exportAttendanceToCSV();
        });
    }
    
    // Logout button
    const logoutButton = document.getElementById('logoutButton');
    if (logoutButton) {
        logoutButton.addEventListener('click', function() {
            console.log('Logout button clicked');
            sessionStorage.clear();
            window.location.href = 'Login-page.html';
        });
    }
}

// Initialize charts
function initCharts() {
    const ctx = document.getElementById('attendanceChart');
    if (!ctx) {
        console.error('Chart canvas not found');
        return;
    }
    
    attendanceChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: chartData.daily.labels,
            datasets: [
                {
                    label: 'Present',
                    data: chartData.daily.present,
                    backgroundColor: '#10b981',
                    borderColor: '#10b981',
                    borderWidth: 1
                },
                {
                    label: 'Absent',
                    data: chartData.daily.absent,
                    backgroundColor: '#ef4444',
                    borderColor: '#ef4444',
                    borderWidth: 1
                },
                {
                    label: 'Late',
                    data: chartData.daily.late,
                    backgroundColor: '#f59e0b',
                    borderColor: '#f59e0b',
                    borderWidth: 1
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
    
    console.log('Attendance chart initialized');
}

// Update chart with new period data
function updateChart(period) {
    if (!attendanceChart || !chartData[period]) {
        console.error('Chart or data not available');
        return;
    }
    
    currentChartPeriod = period;
    
    attendanceChart.data.labels = chartData[period].labels;
    attendanceChart.data.datasets[0].data = chartData[period].present;
    attendanceChart.data.datasets[1].data = chartData[period].absent;
    attendanceChart.data.datasets[2].data = chartData[period].late;
    
    attendanceChart.update();
    console.log('Chart updated to', period);
}

// Helper function for querySelector with contains text
Document.prototype.querySelector = (function(querySelector) {
    return function(selector) {
        if (selector.includes(':contains(')) {
            const match = selector.match(/:contains\("([^"]+)"\)/);
            if (match) {
                const text = match[1];
                const baseSelector = selector.replace(/:contains\("[^"]+"\)/, '');
                const elements = Array.from(this.querySelectorAll(baseSelector));
                return elements.find(el => el.textContent.includes(text)) || null;
            }
        }
        return querySelector.call(this, selector);
    };
})(Document.prototype.querySelector);

// Helper function for querySelectorAll with contains text
Document.prototype.querySelectorAll = (function(querySelectorAll) {
    return function(selector) {
        if (selector.includes(':contains(')) {
            const match = selector.match(/:contains\("([^"]+)"\)/);
            if (match) {
                const text = match[1];
                const baseSelector = selector.replace(/:contains\("[^"]+"\)/, '');
                const elements = Array.from(querySelectorAll.call(this, baseSelector));
                return elements.filter(el => el.textContent.includes(text));
            }
        }
        return querySelectorAll.call(this, selector);
    };
})(Document.prototype.querySelectorAll);
