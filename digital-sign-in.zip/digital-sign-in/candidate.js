// Application State
const state = {
  isAuthenticated: false,
  hasSignedIn: false,
  isLate: false,
  showReasonForm: false,
  showSignInReminder: false,
  attendanceHistory: []
};

// DOM Elements
const elements = {
  // Header elements
  headerUsername: document.getElementById('header-username'),
  headerAvatar: document.getElementById('header-avatar'),
  headerProfileImage: document.getElementById('header-profile-image'),
  
  // Sidebar elements
  sidebarUsername: document.getElementById('sidebar-username'),
  
  // Authentication elements
  loginForm: document.getElementById('login-form'),
  emailInput: document.getElementById('email'),
  passwordInput: document.getElementById('password'),
  loginButton: document.getElementById('login-button'),
  
  // Main content elements
  authContent: document.getElementById('auth-content'),
  mainContent: document.getElementById('main-content'),
  
  // Sign-in elements
  currentTime: document.getElementById('current-time'),
  signInButton: document.getElementById('sign-in-btn'),
  signInStatus: document.getElementById('status-title'),
  signInDescription: document.getElementById('status-description'),
  statusIcon: document.getElementById('status-icon'),
  signInReminder: document.getElementById('sign-in-reminder'),
  
  // Late reason form
  lateReasonForm: document.getElementById('late-reason-form'),
  lateReasonInput: document.getElementById('late-reason'),
  submitReasonBtn: document.getElementById('submit-reason-btn'),
  
  // History elements
  viewHistoryBtn: document.getElementById('view-history-btn'),
  attendanceHistory: document.getElementById('attendance-history'),
  historyTableBody: document.getElementById('history-table-body'),
  downloadBtn: document.getElementById('download-btn'),
  
  // Profile elements
  profileContent: document.getElementById('profile-content'),
  profileFullname: document.getElementById('profile-fullname'),
  profileEmail: document.getElementById('profile-email'),
  profileProgram: document.getElementById('profile-program'),
  profileAvatarContainer: document.getElementById('profile-avatar-container'),
  profileAvatarIcon: document.getElementById('profile-avatar-icon'),
  profileAvatarImage: document.getElementById('profile-avatar-image'),
  profileUpload: document.getElementById('profile-upload'),
  passwordForm: document.getElementById('password-form'),
  
  // Toast container
  toastContainer: document.getElementById('toast-container')
};

// Initialize the application
document.addEventListener('DOMContentLoaded', function() {
  // Check if user is already authenticated
  const userProfileStr = sessionStorage.getItem('userProfile');
  if (userProfileStr) {
    state.isAuthenticated = true;
    initializeMainContent();
  }
  
  // Set up event listeners
  if (elements.signInButton) {
    elements.signInButton.addEventListener('click', handleSignIn);
  }
  
  if (elements.submitReasonBtn) {
    elements.submitReasonBtn.addEventListener('click', handleLateReasonSubmit);
  }
  
  if (elements.viewHistoryBtn) {
    elements.viewHistoryBtn.addEventListener('click', function() {
      if (elements.attendanceHistory) {
        elements.attendanceHistory.classList.toggle('hidden');
      }
    });
  }
  
  if (elements.downloadBtn) {
    elements.downloadBtn.addEventListener('click', downloadAttendanceHistory);
  }
  
  if (elements.profileUpload) {
    elements.profileUpload.addEventListener('change', handleProfilePictureUpload);
  }
  
  // Menu toggle functionality
  const menuToggle = document.getElementById('menu-toggle');
  const sidebar = document.getElementById('sidebar');
  const sidebarOverlay = document.getElementById('sidebar-overlay');
  
  if (menuToggle && sidebar && sidebarOverlay) {
    menuToggle.addEventListener('click', function() {
      sidebar.classList.toggle('active');
      sidebarOverlay.classList.toggle('active');
    });
    
    sidebarOverlay.addEventListener('click', function() {
      sidebar.classList.remove('active');
      sidebarOverlay.classList.remove('active');
    });
  }
  
  // Navigation between dashboard and profile
  const dashboardMenu = document.getElementById('dashboard-menu');
  const profileMenu = document.getElementById('profile-menu');
  const signoutMenu = document.getElementById('signout-menu');
  const dashboardContent = document.getElementById('dashboard-content');
  
  if (dashboardMenu && profileMenu && signoutMenu && dashboardContent && elements.profileContent) {
    dashboardMenu.addEventListener('click', function() {
      dashboardContent.classList.remove('hidden');
      elements.profileContent.classList.add('hidden');
      dashboardMenu.classList.add('active');
      profileMenu.classList.remove('active');
    });
    
    profileMenu.addEventListener('click', function() {
      dashboardContent.classList.add('hidden');
      elements.profileContent.classList.remove('hidden');
      dashboardMenu.classList.remove('active');
      profileMenu.classList.add('active');
    });
    
    signoutMenu.addEventListener('click', function() {
      // Clear session storage
      sessionStorage.removeItem('userProfile');
      // Redirect to login page
      window.location.href = 'Login-page.html';
    });
  }
});

// Time Management
function updateCurrentTime() {
  if (!elements.currentTime) return;
  
  const now = new Date();
  elements.currentTime.textContent = now.toLocaleString('en-US', { 
    weekday: 'long', 
    month: 'long', 
    day: 'numeric', 
    year: 'numeric', 
    hour: '2-digit', 
    minute: '2-digit', 
    second: '2-digit',
    hour12: true 
  });
  
  // Check if sign-in reminder should be shown
  if (!state.hasSignedIn && elements.signInReminder && (now.getHours() < 9 || (now.getHours() === 9 && now.getMinutes() < 15))) {
    state.showSignInReminder = true;
    elements.signInReminder.classList.remove('hidden');
  } else if (elements.signInReminder) {
    state.showSignInReminder = false;
    elements.signInReminder.classList.add('hidden');
  }
  
  updateAttendanceStatus();
}

// Toast Notifications
function showToast(title, message, type = 'info') {
  if (!elements.toastContainer) return;
  
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.innerHTML = `
    <div class="toast-header">
      <strong>${title}</strong>
      <button type="button" class="close-button">&times;</button>
    </div>
    <div class="toast-body">
      ${message}
    </div>
  `;
  
  elements.toastContainer.appendChild(toast);
  
  // Add event listener to close button
  toast.querySelector('.close-button').addEventListener('click', () => {
    toast.classList.add('fade-out');
    setTimeout(() => {
      toast.remove();
    }, 300);
  });
  
  // Auto-remove after 5 seconds
  setTimeout(() => {
    toast.classList.add('fade-out');
    setTimeout(() => {
      toast.remove();
    }, 300);
  }, 5000);
}

// Authentication
async function handleLogin(e) {
  if (e) e.preventDefault();
  
  if (!elements.emailInput || !elements.passwordInput) {
    console.error('Login form elements not found');
    return;
  }
  
  const email = elements.emailInput.value.trim();
  const password = elements.passwordInput.value;
  
  if (!email || !password) {
    showToast('Error', 'Please enter both email and password', 'error');
    return;
  }
  
  try {
    const { data, error } = await window.supabase.auth.signInWithPassword({
      email,
      password
    });
    
    if (error) {
      console.error('Login error:', error);
      showToast('Login Failed', error.message, 'error');
      return;
    }
    
    // Get user profile from Supabase
    const { data: profileData, error: profileError } = await window.supabase
      .from('candidates')
      .select('*')
      .eq('email', email)
      .single();
    
    if (profileError) {
      console.error('Profile fetch error:', profileError);
      showToast('Error', 'Failed to fetch user profile', 'error');
      return;
    }
    
    if (!profileData) {
      showToast('Error', 'User profile not found', 'error');
      return;
    }
    
    // Store user profile in session storage
    sessionStorage.setItem('userProfile', JSON.stringify(profileData));
    
    // Update state
    state.isAuthenticated = true;
    
    // Show success message
    showToast('Success', 'Login successful!', 'success');
    
    // Show main content
    if (elements.authContent && elements.mainContent) {
      elements.authContent.classList.add('hidden');
      elements.mainContent.classList.remove('hidden');
    }
    
    // Initialize main content
    initializeMainContent();
    
  } catch (err) {
    console.error('Login exception:', err);
    showToast('Error', 'An unexpected error occurred', 'error');
  }
}

// Initialize Main Content
async function initializeMainContent() {
  // Start time updates
  updateCurrentTime();
  setInterval(updateCurrentTime, 1000);
  
  // Load user profile
  loadUserProfile();
  
  // Check if already signed in today
  const signedInToday = await hasSignedInToday();
  state.hasSignedIn = signedInToday;
  
  if (signedInToday) {
    updateAttendanceStatus();
  }
  
  // Load attendance history
  await loadAttendanceHistory();
}

// Load User Profile
function loadUserProfile() {
  const userProfileStr = sessionStorage.getItem('userProfile');
  if (!userProfileStr) {
    console.error('No user profile found in session storage');
    return;
  }
  
  const userProfile = JSON.parse(userProfileStr);
  
  // Update header username
  if (elements.headerUsername) {
    elements.headerUsername.textContent = userProfile.full_name || 'User';
  }
  
  // Update sidebar username
  if (elements.sidebarUsername) {
    elements.sidebarUsername.textContent = userProfile.full_name || 'User';
  }
  
  // Update profile elements
  if (elements.profileFullname) {
    elements.profileFullname.textContent = userProfile.full_name || 'N/A';
  }
  
  if (elements.profileEmail) {
    elements.profileEmail.textContent = userProfile.email || 'N/A';
  }
  
  if (elements.profileProgram) {
    elements.profileProgram.textContent = userProfile.cohort || 'N/A';
  }
  
  // Set profile avatar (if available)
  if (userProfile.avatar_url) {
    if (elements.headerProfileImage) {
      elements.headerProfileImage.src = userProfile.avatar_url;
      elements.headerProfileImage.classList.remove('hidden');
      
      if (elements.headerAvatar) {
        const icon = elements.headerAvatar.querySelector('.user-icon');
        if (icon) icon.classList.add('hidden');
      }
    }
    
    if (elements.profileAvatarImage && elements.profileAvatarIcon) {
      elements.profileAvatarImage.src = userProfile.avatar_url;
      elements.profileAvatarImage.classList.remove('hidden');
      elements.profileAvatarIcon.classList.add('hidden');
    }
  }
}

// Update Attendance Status
function updateAttendanceStatus() {
  if (!elements.signInStatus || !elements.signInButton || !elements.statusIcon || !elements.signInDescription) return;
  
  if (state.hasSignedIn) {
    elements.signInStatus.textContent = state.isLate ? 'Late' : 'Present';
    elements.signInDescription.textContent = state.isLate ? 
      'You have been marked as late for today' : 
      'You have been marked as present for today';
    
    elements.statusIcon.textContent = '✓';
    elements.statusIcon.className = state.isLate ? 'status-icon late' : 'status-icon present';
    
    elements.signInButton.disabled = true;
    elements.signInButton.classList.add('disabled');
  } else {
    const now = new Date();
    const isLate = now.getHours() > 9 || (now.getHours() === 9 && now.getMinutes() >= 15);
    
    elements.signInStatus.textContent = isLate ? 'Late' : 'Not Signed In';
    elements.signInDescription.textContent = isLate ? 
      'You are late for today, please sign in with a reason' : 
      'You have not signed in for today yet';
    
    elements.statusIcon.textContent = '✕';
    elements.statusIcon.className = 'status-icon not-signed-in';
    
    elements.signInButton.disabled = false;
    elements.signInButton.classList.remove('disabled');
  }
}

// Check if user has signed in today - Using client-side filtering approach
async function hasSignedInToday() {
  try {
    // Get user profile from session storage
    const userProfileStr = sessionStorage.getItem('userProfile');
    if (!userProfileStr) {
      console.error("No user profile found in session storage");
      return false;
    }
    
    const userProfile = JSON.parse(userProfileStr);
    
    // Get today's date in YYYY-MM-DD format
    const today = new Date().toISOString().split('T')[0];
    
    // Fetch all attendance records for this user
    const { data, error } = await window.supabase
      .from('attendance')
      .select('*')
      .eq('candidate_id', userProfile.id);
    
    if (error) {
      console.error("Error checking today's attendance:", error);
      return false;
    }
    
    // Filter on client side for today's date
    const todayAttendance = data ? data.filter(record => record.date === today) : [];
    
    return todayAttendance.length > 0;
  } catch (err) {
    console.error("Exception checking today's attendance:", err);
    return false;
  }
}

async function handleSignIn() {
  const now = new Date();
  const hour = now.getHours();
  const minute = now.getMinutes();
  const formattedTime = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  // Format date as a simple string to avoid type conversion issues
  const formattedDate = now.toISOString().split('T')[0];
  
  // Check if already signed in today
  const alreadySignedIn = await hasSignedInToday();
  if (alreadySignedIn) {
    showToast(
      "Already Signed In",
      "You have already signed in for today",
      "info"
    );
    state.hasSignedIn = true;
    updateAttendanceStatus();
    return;
  }
  
  let status = "Present";
  if (hour > 9 || (hour === 9 && minute >= 15)) {
    status = "Late";
    state.isLate = true;
    state.showReasonForm = true;
    if (elements.lateReasonForm) {
      elements.lateReasonForm.classList.remove('hidden');
    }
  }
  
  const newAttendance = {
    date: formattedDate,
    time: formattedTime,
    status: status,
    reason: status === "Late" ? "No reason submitted" : "-"
  };
  
  // Save attendance to Supabase
  const saved = await saveAttendanceToSupabase(newAttendance);
  
  if (saved) {
    state.attendanceHistory.unshift(newAttendance);
    state.hasSignedIn = true;
    
    updateAttendanceStatus();
    updateHistoryTable();
    
    showToast(
      "Sign-In Successful",
      `You have been marked as ${status} for today`,
      "success"
    );
  } else {
    showToast(
      "Sign-In Failed",
      "There was an error recording your attendance. Please try again.",
      "error"
    );
  }
}

// Submit late reason
async function handleLateReasonSubmit(e) {
  if (e) e.preventDefault();
  
  if (!elements.lateReasonInput) {
    console.error('Late reason input not found');
    return;
  }
  
  const reason = elements.lateReasonInput.value.trim();
  if (!reason) {
    showToast("Error", "Please provide a reason for being late", "error");
    return;
  }
  
  try {
    // Get user profile from session storage
    const userProfileStr = sessionStorage.getItem('userProfile');
    if (!userProfileStr) {
      console.error("No user profile found in session storage");
      showToast("Error", "User profile not found", "error");
      return;
    }
    
    const userProfile = JSON.parse(userProfileStr);
    
    // Get today's date in YYYY-MM-DD format
    const today = new Date().toISOString().split('T')[0];
    
    // Fetch all attendance records for this user
    const { data: attendanceData, error: fetchError } = await window.supabase
      .from('attendance')
      .select('*')
      .eq('candidate_id', userProfile.id);
    
    if (fetchError) {
      console.error("Error fetching attendance records:", fetchError);
      showToast("Error", "Failed to fetch attendance records", "error");
      return;
    }
    
    // Filter on client side for today's date
    const todayAttendance = attendanceData ? attendanceData.filter(record => record.date === today) : [];
    
    if (todayAttendance.length === 0) {
      console.error("No attendance record found for today");
      showToast("Error", "No attendance record found for today", "error");
      return;
    }
    
    // Get the ID of today's attendance record
    const attendanceId = todayAttendance[0].id;
    
    // Update the attendance record with the reason
    const { data, error } = await window.supabase
      .from('attendance')
      .update({ reason: reason })
      .eq('id', attendanceId);
    
    if (error) {
      console.error("Error updating late reason:", error);
      showToast("Error", "Failed to update reason", "error");
      return;
    }
    
    // Update local state
    const attendanceIndex = state.attendanceHistory.findIndex(a => a.date === today);
    if (attendanceIndex !== -1) {
      state.attendanceHistory[attendanceIndex].reason = reason;
    }
    
    // Hide the form
    if (elements.lateReasonForm) {
      elements.lateReasonForm.classList.add('hidden');
    }
    state.showReasonForm = false;
    
    // Show success message
    showToast("Success", "Late reason submitted successfully", "success");
    
    // Update history table
    updateHistoryTable();
    
  } catch (err) {
    console.error("Exception submitting late reason:", err);
    showToast("Error", "An unexpected error occurred", "error");
  }
}

// Save attendance to Supabase with simple direct insert
async function saveAttendanceToSupabase(attendanceData) {
  try {
    // Get user profile from session storage
    const userProfileStr = sessionStorage.getItem('userProfile');
    if (!userProfileStr) {
      console.error("No user profile found in session storage");
      return false;
    }
    
    const userProfile = JSON.parse(userProfileStr);
    
    // Create a clean record with explicit type handling
    const attendanceRecord = {
  candidate_id: userProfile.id,
  full_name: String(userProfile.full_name || ''),
  cohort: String(userProfile.cohort || ''),
  email: String(userProfile.email || ''),
  // Convert date from YYYY-MM-DD to numeric format (YYYYMMDD)
  date: Number(attendanceData.date.replace(/-/g, '')),
  // Use simple string format for time
  time: String(attendanceData.time || ''),
  status: String(attendanceData.status || 'Present'),
  reason: String(attendanceData.reason || '-')
};
    
    console.log("Saving attendance record to Supabase:", attendanceRecord);
    
    // Simple direct insert - no RPC or fallbacks
    const { data, error } = await window.supabase
      .from('attendance')
      .insert([attendanceRecord]);
    
    if (error) {
      console.error("Error saving attendance to Supabase:", error);
      return false;
    }
    
    console.log("Attendance saved successfully:", data);
    return true;
  } catch (err) {
    console.error("Exception saving attendance to Supabase:", err);
    return false;
  }
}

// Fetch attendance history from Supabase - Using client-side filtering approach
async function fetchAttendanceHistory() {
  try {
    // Get user profile from session storage
    const userProfileStr = sessionStorage.getItem('userProfile');
    if (!userProfileStr) {
      console.error("No user profile found in session storage");
      return [];
    }
    
    const userProfile = JSON.parse(userProfileStr);
    
    // Fetch all attendance records for this user
    const { data, error } = await window.supabase
      .from('attendance')
      .select('*')
      .eq('candidate_id', userProfile.id);
    
    if (error) {
      console.error("Error fetching attendance history:", error);
      return [];
    }
    
    // Sort by date on client side
    const sortedData = data ? [...data].sort((a, b) => {
      // Sort in descending order (newest first)
      return new Date(b.date) - new Date(a.date);
    }) : [];
    
    return sortedData;
  } catch (err) {
    console.error("Exception fetching attendance history:", err);
    return [];
  }
}

// Load attendance history
async function loadAttendanceHistory() {
  const history = await fetchAttendanceHistory();
  state.attendanceHistory = history;
  updateHistoryTable();
}

// Update history table
function updateHistoryTable() {
  if (!elements.historyTableBody) return;
  
  // Clear existing rows
  elements.historyTableBody.innerHTML = '';
  
  // Add rows for each attendance record
  state.attendanceHistory.forEach(record => {
    const row = document.createElement('tr');
    
    row.innerHTML = `
      <td>${record.date}</td>
      <td>${record.time}</td>
      <td><span class="status ${record.status.toLowerCase()}">${record.status}</span></td>
      <td>${record.reason || '-'}</td>
    `;
    
    elements.historyTableBody.appendChild(row);
  });
}

// Download attendance history as CSV
function downloadAttendanceHistory() {
  if (state.attendanceHistory.length === 0) {
    showToast("Error", "No attendance records to download", "error");
    return;
  }
  
  // Create CSV content
  let csvContent = "data:text/csv;charset=utf-8,";
  csvContent += "Date,Time,Status,Reason\n";
  
  state.attendanceHistory.forEach(record => {
    csvContent += `${record.date},${record.time},${record.status},"${record.reason || ''}"\n`;
  });
  
  // Create download link
  const encodedUri = encodeURI(csvContent);
  const link = document.createElement("a");
  link.setAttribute("href", encodedUri);
  link.setAttribute("download", "attendance_history.csv");
  document.body.appendChild(link);
  
  // Trigger download
  link.click();
  
  // Clean up
  document.body.removeChild(link);
}

// Handle profile picture upload
async function handleProfilePictureUpload(e) {
  const file = e.target.files[0];
  if (!file) return;
  
  // Check file type
  if (!file.type.match('image.*')) {
    showToast("Error", "Please select an image file", "error");
    return;
  }
  
  // Check file size (max 5MB)
  if (file.size > 5 * 1024 * 1024) {
    showToast("Error", "Image size should be less than 5MB", "error");
    return;
  }
  
  try {
    // Get user profile from session storage
    const userProfileStr = sessionStorage.getItem('userProfile');
    if (!userProfileStr) {
      console.error("No user profile found in session storage");
      showToast("Error", "User profile not found", "error");
      return;
    }
    
    const userProfile = JSON.parse(userProfileStr);
    
    // Create a unique file name
    const fileExt = file.name.split('.').pop();
    const fileName = `${userProfile.id}_${Date.now()}.${fileExt}`;
    
    // Upload to Supabase Storage
    const { data, error } = await window.supabase.storage
      .from('avatars')
      .upload(fileName, file);
    
    if (error) {
      console.error("Error uploading avatar:", error);
      showToast("Error", "Failed to upload profile picture", "error");
      return;
    }
    
    // Get public URL
    const { data: urlData } = window.supabase.storage
      .from('avatars')
      .getPublicUrl(fileName);
    
    if (!urlData || !urlData.publicUrl) {
      console.error("Error getting public URL");
      showToast("Error", "Failed to get profile picture URL", "error");
      return;
    }
    
    const avatarUrl = urlData.publicUrl;
    
    // Update user profile in Supabase
    const { data: updateData, error: updateError } = await window.supabase
      .from('candidates')
      .update({ avatar_url: avatarUrl })
      .eq('id', userProfile.id);
    
    if (updateError) {
      console.error("Error updating profile:", updateError);
      showToast("Error", "Failed to update profile", "error");
      return;
    }
    
    // Update local profile
    userProfile.avatar_url = avatarUrl;
    sessionStorage.setItem('userProfile', JSON.stringify(userProfile));
    
    // Update UI
    if (elements.profileAvatarImage && elements.profileAvatarIcon) {
      elements.profileAvatarImage.src = avatarUrl;
      elements.profileAvatarImage.classList.remove('hidden');
      elements.profileAvatarIcon.classList.add('hidden');
    }
    
    if (elements.headerProfileImage) {
      elements.headerProfileImage.src = avatarUrl;
      elements.headerProfileImage.classList.remove('hidden');
      
      if (elements.headerAvatar) {
        const icon = elements.headerAvatar.querySelector('.user-icon');
        if (icon) icon.classList.add('hidden');
      }
    }
    
    showToast("Success", "Profile picture updated successfully", "success");
    
  } catch (err) {
    console.error("Exception uploading profile picture:", err);
    showToast("Error", "An unexpected error occurred", "error");
  }
}
